# Quadrature-Encoder

<h3>Description:</h3>
This is sample code for encoder with Arduino + motor driver shield. The Encoder that we used is available <a href="http://www.cytron.com.my/c-84-dc-motor/c-91-dc-geared-motor" target="_blank">here</a>
<br/>

<h3> Tutorial:</h3>
<ul><li><a href="http://tutorial.cytron.com.my/2016/04/04/arduino-2a-motor-shield-encoder-motor/" target="_blank"> Arduino+motor driver shield+encoder motor </a></li></ul>
<h3>Software:</h3>
<ul><li>Arduino IDE</li></ul>
<h3>Hardware:</h3>
<ul><li>Encoder motor</li>
<li> 2A motor driver shield</li>
<li>CT-UNO or Arduino UNO</li>
<li>1K ohm resistor</li>
</ul>

Welcome to our technical forum for further inquiry.
