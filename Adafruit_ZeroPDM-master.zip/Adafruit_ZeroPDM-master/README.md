# Adafruit Zero PDM Library

PDM microphone library for the Arduino Zero / Adafruit Feather M0 (SAMD21 processor).
